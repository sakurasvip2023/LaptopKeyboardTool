﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace LaptopKeyboardTool
{
    public partial class Form1 : Form
    {
        private string cachedInstanceId = null;

        public Form1()
        {
            InitializeComponent();

            this.Shown += Form1_Shown; 

        }


        private void Form1_Shown(object sender, EventArgs e)
        {
            //txtLog.HideSelection = false;
            AppendLog("--- 启动检测 ---");
            DetectCurrentStatus();
        }


        private void DetectCurrentStatus()
        {
            cachedInstanceId = FindPs2StandardKeyboard();

            if (string.IsNullOrEmpty(cachedInstanceId))
            {
                AppendLog("⚠️ 未检测到板载键盘");
                ResetButtonColors();
                return;
            }

            AppendLog($"💡 设备ID: {cachedInstanceId}");

            bool isPnpDisabled = CheckPnpDeviceStatus(cachedInstanceId);
            bool isRegistryDisabled = CheckRegistryStatus();

            UpdateButtonStates(isPnpDisabled, isRegistryDisabled);

            // 显示检测结果
            if (isPnpDisabled)
                AppendLog("→ Pnputil: 已禁用 ✅");
            else
                AppendLog("→ Pnputil: 已启用");

            if (isRegistryDisabled)
                AppendLog("→ 注册表: 已禁用 ✅");
            else
                AppendLog("→ 注册表: 已启用");

            // 推荐方案提示
            if (!isPnpDisabled && !isRegistryDisabled)
                AppendLog("💡 推荐使用方案1 (Pnputil) 禁用键盘");
        }

        /// <summary>
        /// 检查 pnputil 设备是否被禁用
        /// </summary>
        private bool CheckPnpDeviceStatus(string instanceId)
        {
            try
            {
                AppendLog($"[DEBUG] 开始检测 Pnputil 状态...");
                AppendLog($"[DEBUG] 实例ID: {instanceId}");

                // 先尝试直接查询设备
                var psi = new ProcessStartInfo
                {
                    FileName = "pnputil.exe",
                    Arguments = $"/enum-device \"{instanceId}\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.GetEncoding("GBK")
                };

                AppendLog($"[DEBUG] 执行命令: pnputil.exe /enum-device \"{instanceId}\"");

                using (var proc = Process.Start(psi))
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    string error = proc.StandardError.ReadToEnd();
                    proc.WaitForExit();

                    AppendLog($"[DEBUG] 退出码: {proc.ExitCode}");
                    AppendLog($"[DEBUG] 输出长度: {output.Length}");

                    // 输出完整内容（前500字符）
                    if (output.Length > 0)
                    {
                        string preview = output.Length > 500 ? output.Substring(0, 500) + "..." : output;
                        AppendLog($"[DEBUG] 输出内容: {preview}");
                    }

                    if (!string.IsNullOrEmpty(error))
                    {
                        AppendLog($"[DEBUG] 错误信息: {error}");
                    }

                    // 检查输出是否包含"不支持"字样（某些系统不支持 /enum-device）
                    if (output.IndexOf("不支持", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        output.IndexOf("not supported", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        AppendLog($"[DEBUG] /enum-device 不支持，切换到枚举方式");
                        return CheckPnpDeviceStatusByEnum(instanceId);
                    }

                    // 直接查找状态关键字 - 同时检测"已停止"和"已禁用"
                    if (output.IndexOf("状态: 已停止", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        output.IndexOf("状态: 已禁用", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        output.IndexOf("Status: Stopped", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        output.IndexOf("Status: Disabled", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        AppendLog($"[DEBUG] 检测到: 已禁用");
                        return true;
                    }

                    if (output.IndexOf("状态: 已启动", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        output.IndexOf("Status: Started", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        AppendLog($"[DEBUG] 检测到: 已启动");
                        return false;
                    }

                    AppendLog($"[DEBUG] 未找到明确状态，切换到枚举方式");
                    return CheckPnpDeviceStatusByEnum(instanceId);
                }
            }
            catch (Exception ex)
            {
                AppendLog($"[DEBUG] 异常: {ex.Message}");
                return CheckPnpDeviceStatusByEnum(instanceId);
            }
        }

        /// <summary>
        /// 通过枚举键盘类查找设备状态
        /// </summary>
        private bool CheckPnpDeviceStatusByEnum(string instanceId)
        {
            try
            {
                AppendLog($"[DEBUG] 开始枚举键盘设备...");

                var psi = new ProcessStartInfo
                {
                    FileName = "pnputil.exe",
                    Arguments = "/enum-devices /class Keyboard",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.GetEncoding("GBK")
                };

                AppendLog($"[DEBUG] 执行命令: pnputil.exe /enum-devices /class Keyboard");

                using (var proc = Process.Start(psi))
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    proc.WaitForExit();

                    AppendLog($"[DEBUG] 枚举输出长度: {output.Length}");

                    var lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    AppendLog($"[DEBUG] 总行数: {lines.Length}");

                    // 清理实例ID，去掉转义
                    string searchId = instanceId.Replace(@"\", @"\\");
                    AppendLog($"[DEBUG] 搜索ID: {searchId}");

                    bool foundDevice = false;
                    int lineIndex = 0;

                    for (int i = 0; i < lines.Length; i++)
                    {
                        string line = lines[i].Trim();

                        // 匹配实例 ID
                        if (line.StartsWith("实例 ID:", StringComparison.OrdinalIgnoreCase))
                        {
                            string id = line.Substring("实例 ID:".Length).Trim();
                            AppendLog($"[DEBUG] 发现设备: {id}");

                            // 比较是否匹配（忽略大小写）
                            if (string.Equals(id, instanceId, StringComparison.OrdinalIgnoreCase) ||
                                id.IndexOf(searchId, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                foundDevice = true;
                                lineIndex = i;
                                AppendLog($"[DEBUG] ✅ 找到匹配设备，行号: {i}");
                                break;
                            }
                        }
                    }

                    if (!foundDevice)
                    {
                        AppendLog($"[DEBUG] ❌ 未找到匹配设备");
                        return false;
                    }

                    // 找到设备，往后查找状态
                    for (int j = lineIndex + 1; j < Math.Min(lineIndex + 15, lines.Length); j++)
                    {
                        string statusLine = lines[j].Trim();
                        AppendLog($"[DEBUG] 检查状态行: {statusLine}");

                        if (statusLine.StartsWith("状态:", StringComparison.OrdinalIgnoreCase))
                        {
                            string status = statusLine.Substring("状态:".Length).Trim();
                            // 判断是否禁用：已停止 或 已禁用
                            bool isDisabled = status.Contains("已停止") || status.Contains("已禁用");
                            AppendLog($"[DEBUG] 设备状态: {status} -> 已禁用: {isDisabled}");
                            return isDisabled;
                        }
                    }

                    AppendLog($"[DEBUG] ⚠️ 未找到状态信息，默认返回已启用");
                    return false;
                }
            }
            catch (Exception ex)
            {
                AppendLog($"[DEBUG] 枚举异常: {ex.Message}");
                return false;
            }
        }

        private bool CheckRegistryStatus()
        {
            const string regPath = @"SYSTEM\CurrentControlSet\Services\i8042prt";
            try
            {
                AppendLog($"[DEBUG] 检查注册表: {regPath}");
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(regPath))
                {
                    if (key == null)
                    {
                        AppendLog($"[DEBUG] 注册表键不存在");
                        return false;
                    }
                    object value = key.GetValue("Start");
                    bool isDisabled = value is int startValue && startValue == 4;
                    AppendLog($"[DEBUG] Start 值: {value} -> 已禁用: {isDisabled}");
                    return isDisabled;
                }
            }
            catch (Exception ex)
            {
                AppendLog($"[DEBUG] 注册表异常: {ex.Message}");
                return false;
            }
        }

        private void UpdateButtonStates(bool isPnpDisabled, bool isRegistryDisabled)
        {
            ResetButtonColors();

            // 两个独立判断，各自独立显示状态
            if (isPnpDisabled)
            {
                btnPnpEnable.BackColor = System.Drawing.Color.LightGreen;
                btnPnpEnable.Text = "✅ 恢复 (Pnputil)";
            }

            if (isRegistryDisabled)
            {
                btnRegEnable.BackColor = System.Drawing.Color.LightGreen;
                btnRegEnable.Text = "✅ 恢复 (注册表)";
            }

            // 只有在两个都没有禁用时，才让禁用按钮变绿表示"可安全禁用"
            if (!isPnpDisabled && !isRegistryDisabled)
            {
                btnPnpDisable.BackColor = System.Drawing.Color.LightGreen;
                btnRegDisable.BackColor = System.Drawing.Color.LightGreen;
            }
        }

        private void ResetButtonColors()
        {
            btnPnpDisable.BackColor = System.Drawing.SystemColors.Control;
            btnPnpEnable.BackColor = System.Drawing.SystemColors.Control;
            btnRegDisable.BackColor = System.Drawing.SystemColors.Control;
            btnRegEnable.BackColor = System.Drawing.SystemColors.Control;

            btnPnpEnable.Text = "恢复 (Pnputil)";
            btnRegEnable.Text = "恢复 (注册表)";
        }

        private void RefreshStatus()
        {
            DetectCurrentStatus();
        }

        private void btnPnpDisable_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cachedInstanceId))
                cachedInstanceId = FindPs2StandardKeyboard();

            if (!string.IsNullOrEmpty(cachedInstanceId))
            {
                PnputilDisable(cachedInstanceId);
                AppendLog("→ 需要重启生效");
            }
        }

        private void btnPnpEnable_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cachedInstanceId))
                cachedInstanceId = FindPs2StandardKeyboard();

            if (!string.IsNullOrEmpty(cachedInstanceId))
            {
                PnputilEnable(cachedInstanceId);
                RefreshStatus();
            }
        }

        private void btnRegDisable_Click(object sender, EventArgs e)
        {
            RegSetI8042Prt(4);
            AppendLog("→ 需要重启生效");
        }

        private void btnRegEnable_Click(object sender, EventArgs e)
        {
            RegSetI8042Prt(0);
            RefreshStatus();
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            txtLog.Clear();
        }

        private void btn_re_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "确认重启电脑吗？",
                "确认重启",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                AppendLog("→ 正在重启电脑...");

                var psi = new ProcessStartInfo
                {
                    FileName = "shutdown.exe",
                    Arguments = "/r /t 1 /c \"电脑即将重启...\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                Process.Start(psi);
            }
        }

        // ========== 以下为原有方法 ==========

        private void AppendLog(string msg)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action(() => AppendLog(msg)));
                return;
            }
            txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
            // TextBox 滚动到底部 - 方法4：使用 Win32 API 或直接设置
            txtLog.Select(txtLog.Text.Length, 0);
            txtLog.ScrollToCaret();
        }

        private string FindPs2StandardKeyboard()
        {
            AppendLog("[DEBUG] 开始查找板载键盘...");

            var psi = new ProcessStartInfo
            {
                FileName = "pnputil.exe",
                Arguments = "/enum-devices /class Keyboard",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.GetEncoding("GBK")
            };

            using (var proc = Process.Start(psi))
            {
                string output = proc.StandardOutput.ReadToEnd();
                proc.WaitForExit();

                AppendLog($"[DEBUG] 枚举输出长度: {output.Length}");

                var lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                AppendLog($"[DEBUG] 总行数: {lines.Length}");

                string currentInstanceId = null;
                StringBuilder currentBlock = new StringBuilder();

                // 收集所有匹配的设备
                List<KeyboardDevice> candidates = new List<KeyboardDevice>();

                foreach (var line in lines)
                {
                    string trimLine = line.TrimStart();

                    if (trimLine.StartsWith("实例 ID:", StringComparison.Ordinal))
                    {
                        // 保存上一个设备
                        if (currentInstanceId != null)
                        {
                            string blockText = currentBlock.ToString();
                            if (IsBuiltinKeyboard(currentInstanceId, blockText))
                            {
                                string desc = ExtractDescription(blockText);
                                candidates.Add(new KeyboardDevice
                                {
                                    InstanceId = currentInstanceId,
                                    Description = desc,
                                    Status = ExtractStatus(blockText)
                                });
                                AppendLog($"[DEBUG] 候选设备: {currentInstanceId} -> {desc}");
                            }
                        }

                        // 开始新设备
                        currentInstanceId = trimLine.Substring("实例 ID:".Length).Trim();
                        currentBlock.Clear();
                        currentBlock.AppendLine(trimLine);
                    }
                    else
                    {
                        if (currentInstanceId != null)
                            currentBlock.AppendLine(trimLine);
                    }
                }

                // 处理最后一个设备
                if (currentInstanceId != null)
                {
                    string blockText = currentBlock.ToString();
                    if (IsBuiltinKeyboard(currentInstanceId, blockText))
                    {
                        string desc = ExtractDescription(blockText);
                        candidates.Add(new KeyboardDevice
                        {
                            InstanceId = currentInstanceId,
                            Description = desc,
                            Status = ExtractStatus(blockText)
                        });
                        AppendLog($"[DEBUG] 候选设备: {currentInstanceId} -> {desc}");
                    }
                }

                AppendLog($"[DEBUG] 找到 {candidates.Count} 个候选设备");

                // 如果没有候选设备，直接匹配 ACPI\MSFT0001 开头的任意设备
                if (candidates.Count == 0)
                {
                    AppendLog("[DEBUG] 没有候选设备，尝试宽松匹配 ACPI\\MSFT0001...");

                    // 重新扫描，只匹配 ACPI\MSFT0001 开头
                    currentInstanceId = null;
                    currentBlock.Clear();

                    foreach (var line in lines)
                    {
                        string trimLine = line.TrimStart();

                        if (trimLine.StartsWith("实例 ID:", StringComparison.Ordinal))
                        {
                            if (currentInstanceId != null)
                            {
                                string blockText = currentBlock.ToString();
                                if (currentInstanceId.StartsWith(@"ACPI\MSFT0001", StringComparison.OrdinalIgnoreCase))
                                {
                                    string desc = ExtractDescription(blockText);
                                    candidates.Add(new KeyboardDevice
                                    {
                                        InstanceId = currentInstanceId,
                                        Description = desc,
                                        Status = ExtractStatus(blockText)
                                    });
                                    AppendLog($"[DEBUG] 宽松匹配: {currentInstanceId} -> {desc}");
                                }
                            }

                            currentInstanceId = trimLine.Substring("实例 ID:".Length).Trim();
                            currentBlock.Clear();
                            currentBlock.AppendLine(trimLine);
                        }
                        else
                        {
                            if (currentInstanceId != null)
                                currentBlock.AppendLine(trimLine);
                        }
                    }

                    if (currentInstanceId != null)
                    {
                        string blockText = currentBlock.ToString();
                        if (currentInstanceId.StartsWith(@"ACPI\MSFT0001", StringComparison.OrdinalIgnoreCase))
                        {
                            string desc = ExtractDescription(blockText);
                            candidates.Add(new KeyboardDevice
                            {
                                InstanceId = currentInstanceId,
                                Description = desc,
                                Status = ExtractStatus(blockText)
                            });
                            AppendLog($"[DEBUG] 宽松匹配: {currentInstanceId} -> {desc}");
                        }
                    }
                }

                // 精确匹配：必须是 ACPI\MSFT0001 开头的 PS/2 标准键盘
                var exactMatch = candidates.Find(c =>
                    c.InstanceId.StartsWith(@"ACPI\MSFT0001", StringComparison.OrdinalIgnoreCase) &&
                    (c.Description.Contains("PS/2 标准键盘") || c.Description.Contains("Standard PS/2 Keyboard"))
                );

                if (exactMatch != null)
                {
                    AppendLog($"✅ 找到板载键盘: {exactMatch.InstanceId}");
                    return exactMatch.InstanceId;
                }

                // 备用匹配：如果没找到精确匹配，用 ACPI\MSFT0001 开头的任意键盘
                var fallback = candidates.Find(c =>
                    c.InstanceId.StartsWith(@"ACPI\MSFT0001", StringComparison.OrdinalIgnoreCase)
                );

                if (fallback != null)
                {
                    AppendLog($"✅ 找到板载键盘: {fallback.InstanceId}");
                    return fallback.InstanceId;
                }

                AppendLog("❌ 未找到 ACPI\\MSFT0001 板载键盘");
                return null;
            }
        }

        /// <summary>
        /// 判断是否为板载键盘
        /// </summary>
        private bool IsBuiltinKeyboard(string instanceId, string blockText)
        {
            // 板载键盘必须满足：ACPI\MSFT0001 开头
            if (!instanceId.StartsWith(@"ACPI\MSFT0001", StringComparison.OrdinalIgnoreCase))
                return false;

            // 至少包含键盘相关信息（放宽条件）
            if (blockText.IndexOf("Keyboard", StringComparison.OrdinalIgnoreCase) < 0 &&
                blockText.IndexOf("键盘", StringComparison.OrdinalIgnoreCase) < 0)
                return false;

            return true;
        }

        /// <summary>
        /// 提取设备描述
        /// </summary>
        private string ExtractDescription(string blockText)
        {
            var lines = blockText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                string trimLine = line.TrimStart();
                if (trimLine.StartsWith("设备描述:", StringComparison.OrdinalIgnoreCase))
                {
                    return trimLine.Substring("设备描述:".Length).Trim();
                }
            }
            return "未知";
        }

        /// <summary>
        /// 提取设备状态
        /// </summary>
        private string ExtractStatus(string blockText)
        {
            var lines = blockText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                string trimLine = line.TrimStart();
                if (trimLine.StartsWith("状态:", StringComparison.OrdinalIgnoreCase))
                {
                    return trimLine.Substring("状态:".Length).Trim();
                }
            }
            return "未知";
        }

        private void PnputilDisable(string instanceId)
        {
            AppendLog($"[DEBUG] 执行禁用: {instanceId}");

            var psi = new ProcessStartInfo
            {
                FileName = "pnputil.exe",
                Arguments = $"/disable-device \"{instanceId}\" /force",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.GetEncoding("GBK")
            };
            using (var p = Process.Start(psi))
            {
                string stdout = p.StandardOutput.ReadToEnd();
                string stderr = p.StandardError.ReadToEnd();
                p.WaitForExit();

                AppendLog($"[DEBUG] 禁用退出码: {p.ExitCode}");

                if (!string.IsNullOrEmpty(stdout))
                    AppendLog($"[DEBUG] 输出: {stdout.Trim()}");
                if (!string.IsNullOrEmpty(stderr))
                    AppendLog($"[DEBUG] 错误: {stderr.Trim()}");

                if (p.ExitCode == 0 || p.ExitCode == 3010)
                {
                    AppendLog("✅ 禁用成功");
                }
                else
                {
                    AppendLog($"❌ 禁用失败 ({p.ExitCode})");
                }
            }
        }

        private void PnputilEnable(string instanceId)
        {
            AppendLog($"[DEBUG] 执行启用: {instanceId}");

            var psi = new ProcessStartInfo
            {
                FileName = "pnputil.exe",
                Arguments = $"/enable-device \"{instanceId}\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.GetEncoding("GBK")
            };
            using (var p = Process.Start(psi))
            {
                string stdout = p.StandardOutput.ReadToEnd();
                string stderr = p.StandardError.ReadToEnd();
                p.WaitForExit();

                AppendLog($"[DEBUG] 启用退出码: {p.ExitCode}");

                if (!string.IsNullOrEmpty(stdout))
                    AppendLog($"[DEBUG] 输出: {stdout.Trim()}");
                if (!string.IsNullOrEmpty(stderr))
                    AppendLog($"[DEBUG] 错误: {stderr.Trim()}");

                if (p.ExitCode == 0 || p.ExitCode == 3010 || p.ExitCode == 50)
                {
                    AppendLog("✅ 启用成功");
                }
                else
                {
                    AppendLog($"❌ 启用失败 ({p.ExitCode})");
                }
            }
        }

        private void RegSetI8042Prt(int startValue)
        {
            const string regPath = @"SYSTEM\CurrentControlSet\Services\i8042prt";
            try
            {
                AppendLog($"[DEBUG] 修改注册表: {regPath} Start={startValue}");

                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(regPath, RegistryKeyPermissionCheck.ReadWriteSubTree))
                {
                    if (key == null)
                    {
                        AppendLog("⚠️ i8042prt 不存在");
                        return;
                    }
                    key.SetValue("Start", startValue, RegistryValueKind.DWord);
                    AppendLog($"✅ 注册表已修改 (Start={startValue})");
                }
            }
            catch (Exception ex)
            {
                AppendLog($"[DEBUG] 注册表异常: {ex.Message}");
                AppendLog($"❌ 注册表失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 键盘设备信息
        /// </summary>
        private class KeyboardDevice
        {
            public string InstanceId { get; set; }
            public string Description { get; set; }
            public string Status { get; set; }
        }
    }
}