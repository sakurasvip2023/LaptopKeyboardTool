﻿namespace LaptopKeyboardTool
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPnpDisable = new System.Windows.Forms.Button();
            this.btnPnpEnable = new System.Windows.Forms.Button();
            this.btnRegDisable = new System.Windows.Forms.Button();
            this.btnRegEnable = new System.Windows.Forms.Button();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_re = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPnpDisable
            // 
            this.btnPnpDisable.Location = new System.Drawing.Point(24, 24);
            this.btnPnpDisable.Name = "btnPnpDisable";
            this.btnPnpDisable.Size = new System.Drawing.Size(170, 48);
            this.btnPnpDisable.TabIndex = 0;
            this.btnPnpDisable.Text = "方案1\r\nPnP提交禁用键盘";
            this.btnPnpDisable.UseVisualStyleBackColor = true;
            this.btnPnpDisable.Click += new System.EventHandler(this.btnPnpDisable_Click);
            // 
            // btnPnpEnable
            // 
            this.btnPnpEnable.Location = new System.Drawing.Point(210, 24);
            this.btnPnpEnable.Name = "btnPnpEnable";
            this.btnPnpEnable.Size = new System.Drawing.Size(170, 48);
            this.btnPnpEnable.TabIndex = 1;
            this.btnPnpEnable.Text = "方案1\r\nPnP恢复键盘";
            this.btnPnpEnable.UseVisualStyleBackColor = true;
            this.btnPnpEnable.Click += new System.EventHandler(this.btnPnpEnable_Click);
            // 
            // btnRegDisable
            // 
            this.btnRegDisable.Location = new System.Drawing.Point(24, 78);
            this.btnRegDisable.Name = "btnRegDisable";
            this.btnRegDisable.Size = new System.Drawing.Size(170, 46);
            this.btnRegDisable.TabIndex = 2;
            this.btnRegDisable.Text = "方案2\r\n注册表i8042prt禁用";
            this.btnRegDisable.UseVisualStyleBackColor = true;
            this.btnRegDisable.Click += new System.EventHandler(this.btnRegDisable_Click);
            // 
            // btnRegEnable
            // 
            this.btnRegEnable.Location = new System.Drawing.Point(210, 78);
            this.btnRegEnable.Name = "btnRegEnable";
            this.btnRegEnable.Size = new System.Drawing.Size(170, 46);
            this.btnRegEnable.TabIndex = 3;
            this.btnRegEnable.Text = "方案2\r\n注册表i8042prt恢复";
            this.btnRegEnable.UseVisualStyleBackColor = true;
            this.btnRegEnable.Click += new System.EventHandler(this.btnRegEnable_Click);
            // 
            // btnClearLog
            // 
            this.btnClearLog.Location = new System.Drawing.Point(502, 28);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(120, 32);
            this.btnClearLog.TabIndex = 4;
            this.btnClearLog.Text = "清空日志";
            this.btnClearLog.UseVisualStyleBackColor = true;
            this.btnClearLog.Visible = false;
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);
            // 
            // txtLog
            // 
            this.txtLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLog.Location = new System.Drawing.Point(12, 179);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(388, 105);
            this.txtLog.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 302);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 60);
            this.label1.TabIndex = 6;
            this.label1.Text = "⚠️管理员身份运行\r\n单次只用一种方案，操作需重启生效；\r\n推荐使用方案1，恢复可以直接生效;\r\n键盘异常可使用屏幕键盘，点启用后重启恢复。";
            // 
            // btn_re
            // 
            this.btn_re.Location = new System.Drawing.Point(24, 130);
            this.btn_re.Name = "btn_re";
            this.btn_re.Size = new System.Drawing.Size(170, 43);
            this.btn_re.TabIndex = 7;
            this.btn_re.Text = "一键重启";
            this.btn_re.UseVisualStyleBackColor = true;
            this.btn_re.Click += new System.EventHandler(this.btn_re_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 374);
            this.Controls.Add(this.btn_re);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.btnClearLog);
            this.Controls.Add(this.btnRegEnable);
            this.Controls.Add(this.btnRegDisable);
            this.Controls.Add(this.btnPnpEnable);
            this.Controls.Add(this.btnPnpDisable);
            this.Name = "Form1";
            this.Text = "笔记本键盘禁用工具";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPnpDisable;
        private System.Windows.Forms.Button btnPnpEnable;
        private System.Windows.Forms.Button btnRegDisable;
        private System.Windows.Forms.Button btnRegEnable;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_re;
    }
}
